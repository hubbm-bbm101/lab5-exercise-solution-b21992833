import random
number = random.randint(0,100)
while True :
    yourNumber = int(input("number"))
    if yourNumber > number :
        print("decrase your number")
    elif yourNumber < number :
        print("incrase your number")
    else:
        print("your guess is correct")
        break
